export interface MobiusStripParams {
  radius: number;
  width: number;
  resolution: number;
}

export interface MobiusStripProperties {
  surfaceArea: number;
  edgeLength: number;
}

export interface Point3D {
  x: number;
  y: number;
  z: number;
}

export interface MobiusStripData {
  points: Point3D[][][];
  properties: MobiusStripProperties;
}