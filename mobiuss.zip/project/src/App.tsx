import React, { useState } from 'react';
import { SettingsIcon, Info, Github, Download } from 'lucide-react';
import ParameterForm from './components/ParameterForm';
import MobiusVisualization from './components/MobiusVisualization';
import PropertiesDisplay from './components/PropertiesDisplay';
import MathematicalDetails from './components/MathematicalDetails';
import { MobiusStripParams, MobiusStripProperties } from './types';
import { calculateMobiusStripData } from './utils/mobiusCalculator';

function App() {
  const [params, setParams] = useState<MobiusStripParams>({
    radius: 2,
    width: 1,
    resolution: 50
  });
  
  const [properties, setProperties] = useState<MobiusStripProperties>({
    surfaceArea: 0,
    edgeLength: 0
  });
  
  const [showMath, setShowMath] = useState(false);
  
  const handleParamChange = (newParams: MobiusStripParams) => {
    setParams(newParams);
    
    // Calculate new properties
    const data = calculateMobiusStripData(newParams);
    setProperties(data.properties);
  };
  
  const toggleMathDetails = () => {
    setShowMath(!showMath);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200">
      {/* Header */}
      <header className="bg-gray-800 py-4 px-6 flex justify-between items-center border-b border-gray-700">
        <div className="flex items-center space-x-2">
          <SettingsIcon className="h-6 w-6 text-teal-400" />
          <h1 className="text-xl font-bold">Mobius Strip Modeler</h1>
        </div>
        <div className="flex space-x-4">
          <button 
            onClick={toggleMathDetails}
            className="flex items-center space-x-1 text-sm px-3 py-1 rounded bg-gray-700 hover:bg-gray-600 transition-colors"
          >
            <Info className="h-4 w-4" />
            <span>{showMath ? 'Hide Math' : 'Show Math'}</span>
          </button>
          <a 
            href="/python/mobius_strip.py" 
            download
            className="flex items-center space-x-1 text-sm px-3 py-1 rounded bg-blue-700 hover:bg-blue-600 transition-colors"
          >
            <Download className="h-4 w-4" />
            <span>Download Script</span>
          </a>
          <a 
            href="https://github.com" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center text-gray-400 hover:text-white transition-colors"
          >
            <Github className="h-5 w-5" />
          </a>
        </div>
      </header>
      
      <main className="container mx-auto px-4 py-8 flex flex-col lg:flex-row gap-8">
        {/* Left column - Parameters and Properties */}
        <div className="lg:w-1/3 space-y-6">
          <ParameterForm params={params} onChange={handleParamChange} />
          <PropertiesDisplay properties={properties} />
        </div>
        
        {/* Right column - Visualization */}
        <div className="lg:w-2/3 bg-gray-800 rounded-lg overflow-hidden border border-gray-700 shadow-lg">
          <MobiusVisualization params={params} />
        </div>
      </main>
      
      {/* Mathematical Details Modal */}
      {showMath && (
        <MathematicalDetails onClose={toggleMathDetails} />
      )}
      
      {/* Footer */}
      <footer className="bg-gray-800 py-3 px-6 text-center text-gray-500 text-sm border-t border-gray-700">
        <p>© 2025 Mobius Strip Modeler • Assignment deadline: 6:30 pm on 27th May 2025</p>
      </footer>
    </div>
  );
}

export default App;